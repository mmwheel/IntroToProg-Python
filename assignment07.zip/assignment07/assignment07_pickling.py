'''
Title: Exception Handling in Python
Dev:MMWheeler
ChangeLog:12/11/18, created script
Create a script that allows users to store sample ids, variant, and p-values.
'''

import pickle # import pickle

###Data###
objFile = None
strSampleInput = None
strVariantInput = None
intUserInput = None
lsVariants = None

####Processing####
def WriteUserInput(File):
#Use try and except to handle input errors
    try:
        print("This program stores sample ID, Variant Type and length to file")
        while(True):
            strUserInput = input('Would you like to enter a new data entry (y/n)?')
            if (strUserInput.lower() == 'n'):
                print("You have chosen to exit the program")
                break
            else:
                strSampleInput = input('Enter sample ID:')
                strVariantInput = input('Enter the variant (e.g. DELETION, DUPLICATION):')
                intUserInput = int(input('Enter variant length:'))
                lsVariants = [strVariantInput, strVariantInput]
                pickle.dump(lsVariants, objFile)  # this stores the data in binary format
    except Exception as e:
        print('There was an error!')
        print(e)

#I/O
try:
    objFile = open('variants.dat', 'ab')
    WriteUserInput(objFile)
except:
    print(error)


