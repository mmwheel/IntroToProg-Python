'''
Title: Exception Handling in Python
Dev:MMWheeler
ChangeLog:12/11/18, created script
Create a script that allows users to store sample ids, variant, and p-values.
'''



###Data###
objFile = None
strSampleInput = None
strVariantInput = None
intUserInput = None

####Processing####
def WriteUserInput(File):
#Use try and except to handle input errors
    try:
        print("This program stores sample ID, Variant Type and length to file")
        while(True):
            strUserInput = input('Would you like to enter a new data entry (y/n)?')
            if (strUserInput.lower() == 'n'):
                print("You have chosen to exit the program")
                break
            else:
                strSampleInput = input('Enter sample ID:')
                strVariantInput = input('Enter the variant (e.g. DELETION, DUPLICATION):')
                intUserInput = int(input('Enter variant length:'))
                objFile.write(strSampleInput + "\t" + strVariantInput + "\t" + str(intUserInput) + "\n")
    except Exception as e:
        print('There was an error!')
        print(e)

def ReadAllFileData(File, Message):
    try:
        print(Message)
        File.seek(0)
        print(File.read())
    except Exception as e:
        print('There was an error!')
        print(e)

#I/O
try:
    objFile = open('variants.txt', 'r+')
    ReadAllFileData(objFile, "Here is the current data:")
    WriteUserInput(objFile)
    ReadAllFileData(objFile, "Here is the current data:")
except Exception as e:
    print('There was an error!')
    print(e)
finally:
    if(objFile != None):
        objFile.close()