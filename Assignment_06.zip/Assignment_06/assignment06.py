'''
Project Title:Assignment_06
Dev:MMWheeler
Date:11-24-18
ChangeLog:MMwheeler, 11-24-18, created
'''

'''Create a new script that manages a "ToDo list." This project is like 
to the last one, but different enough to be a challenge. 
This project is very like the last one, but this time 
you will place the code you created for working with your ToDo.txt file 
into Functions and a Class.
'''

#---------Data and Variable Names---------#
# Step 1 - Load data from a file
myFile = open('todo_list.txt', 'r')


#---------Processing---------#

#Make a class which groups functions
class ProcessTodoList(object):
    global lsTable
    lsTable = []

    def loadItems(file):
        for lines in file:
            linesStrip = lines.strip('\n')
            linesSplit = linesStrip.split(",")
            dictRow = {"Item": str(linesSplit[0]), "Priority": str(linesSplit[1])}
            lsTable.append(dictRow)

    #Function to display items to user
    @staticmethod
    def ShowItems():
        for items in lsTable:
            print(items["Item"] + ',' + items["Priority"])

    #Function to add an item to the list
    @staticmethod
    def AddItem(newItem, newPriority):
        dictNew = {"Item": newItem, "Priority": newPriority}
        lsTable.append(dictNew)

    #Function to remove an item from the list
    @staticmethod
    def RemoveItem(intRemoveItem):
        strRemoveItem = lsTable[intRemoveItem]
        lsTable.remove(strRemoveItem)

    #Function to save Items to a file
    @staticmethod
    def SaveItems():
        newTodoList = open('todo_list.txt', 'w')
        for items in lsTable:
            newTodoList.write(items["Item"] + ',' + items["Priority"] + '\n')
        newTodoList.close()

#---------Presentation---------#
#Make a class which groups functions
#call function that loads file

ProcessTodoList.loadItems(myFile)

while(True):
    strUserInput = input(
        "Please select a number indicating the following choices:\n 1: Show current data\n 2: Add a new item.\n "
        "3: Remove an existing item.\n 4: Save Data to File\n 5: Exit Program\n")
#Step 1:
    if (strUserInput.strip() == '1'):
        print('------Your current todo items include -------')
        ProcessTodoList.ShowItems()
        print('---------------------------------------------')
# Step 2:
    elif (strUserInput.strip() == '2'):
        strNewItem = input("Please enter a new item:").capitalize()
        strNewPriority = input("Please enter a priority:").lower()
        ProcessTodoList.AddItem(strNewItem, strNewPriority)
        print('------Your current todo items include -------')
        ProcessTodoList.ShowItems()
        print('---------------------------------------------')
# Step 3:
    elif (strUserInput.strip() == '3'):
        try:
            intRemove = int(input('Please enter the index of the item you want to remove:'))
            ProcessTodoList.RemoveItem(intRemove)
            print('------Your current todo items include -------')
            ProcessTodoList.ShowItems()
            print('---------------------------------------------')
        except:
            print('You did not choose a valid index! Please try again')

# Step 4:
    elif (strUserInput.strip() == '4'):
        print('Your have chosen to save your items to file, please note this option overwrites your current list')
        print('------Your current todo items include -------')
        ProcessTodoList.ShowItems()
        print('---------------------------------------------')
        ProcessTodoList.SaveItems()
# Step 5:
    elif (strUserInput.strip() == '5'):
        print('You chose to exit the program, goodbye')
        break









