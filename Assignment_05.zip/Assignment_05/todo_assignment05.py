'''
Project Title:Assignment_05
Dev:MMWheeler
Date:11-18-18
ChangeLog:MMwheeler, 11-18-18, created
'''

'''This time the ToDo file will contain different columns of data (Task, Priority) 
which are stored in a Python Dictionary. Each Dictionary will represent one row of data 
and these rows of data are added to a Python List to create a table of data.
'''

# Step 1 - Load data from a file
myFile = open('todo_list.txt', 'r')
#myFileLines = myFile.readlines()

#Load each row into a dictionary
lsTodoTable = []

for lines in myFile:
   linesStrip = lines.strip('\n')
   linesSplit = linesStrip.split(",")
   dictRow = {"Item": str(linesSplit[0]), "Priority": str(linesSplit[1])}
   lsTodoTable.append(dictRow)
                                # Add the new dictionary “row” into a Python list object


# Step 2 - Display a menu of choices to the user
while(True):
    strUserInput = input("Please select a number indicating the following choices:\n 1: Show current data\n 2: Add a new item.\n "
                         "3: Remove an existing item.\n 4: Save Data to File\n 5: Exit Program\n")
#Show current data
    if(strUserInput.strip() == '1'):
        print('------Your current todo items include -------')
        for items in lsTodoTable:
            print(items["Item"] + ',' + items["Priority"] + '\n')
        print('---------------------------------------------')
#Add a new item
    elif(strUserInput.strip() == '2'):
        strNewItem = input("Please enter a new item:")
        strNewPriority = input("Please enter a priority:")
        dictNew = {"Item": strNewItem, "Priority": strNewPriority}
        lsTodoTable.append(dictNew)
#Remove an existing item
    elif(strUserInput.strip() == '3'):
        print(len(lsTodoTable))
        intRemove = int(input('Please enter the index of the item you want to remove:'))
        strItem = lsTodoTable[intRemove]
        lsTodoTable.remove(strItem)
#Save Data to File
    elif (strUserInput.strip() == '4'):
        print('Your have chosen to save your items to file, please note this option overwrite your current list')
        print('------Your current todo items include -------')
        for items in lsTodoTable:
            print(items["Item"] + ',' + items["Priority"] + '\n')
        print('---------------------------------------------')

        newTodoList = open('todo_list.txt', 'w')
        for items in lsTodoTable:
            newTodoList.write(items["Item"] + ',' + items["Priority"] + '\n')
        newTodoList.close()

#Exit Program
    elif (strUserInput.strip() == '5'):
        print('You chose to exit the program, goodbye')
        break










